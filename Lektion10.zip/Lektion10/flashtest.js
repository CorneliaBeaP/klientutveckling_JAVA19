if (Modernizr.flash) {
    console.log("Flash is supported");
    
  } else {
    console.error("Flash is not supported");  }